package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//include functions: on/off taxi stand locations, choose radius, change password
public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }
}
